import matplotlib
#matplotlib.use('agg')
import matplotlib.pyplot as plt
import tensorflow as tf
import psutil
import numpy as np
import os
from PIL import Image
data = np.random.randint(0, 20, size=(1, 2, 3, 4))
print(len(data))
def save_image_for_PU(data):
  for j in range(len(data)):
    X, y = data[j]
        #subdir = os.path.join(self.save_path, subdir)
        #if not os.path.exists(subdir):
            #os.mkdir(subdir)

        # Plot each sample in the batch
    for i, (im, lab) in enumerate(zip(X, y)):
            #fig, (ax1, ax2) = plt.subplots(ncols=3, figsize=(12, 6))
      #lab = lab.reshape(im.shape[:-1] + (lab.shape[-1],))
      #im = im.reshape(im.shape[:-1] + (lab.shape[-1],))
            # Imshow ground truth on ax2
            # This function will determine which channel, axis and slice to
            # show and return so that we can use them for the other 2 axes
            #chnl, axis, slice = imshow_with_label_overlay(ax2, im, lab, lab_alpha=1.0)

            # Imshow pred on ax3
            #imshow_with_label_overlay(ax3, im, p, lab_alpha=1.0,
                                      #channel=chnl, axis=axis, slice=slice)

            # Imshow raw image on ax1
            # Chose the same slice, channel and axis as above
            #im = im[..., chnl]
            #im = np.moveaxis(im, axis, 0)
            #if slice is not None:
                # Only for 3D imges
                #im = im[slice]
            #ax1.imshow(im, cmap="gray")

            # Set labels
            #ax1.set_title("Image", size=18)
            #ax2.set_title("True labels", size=18)
            #ax3.set_title("Prediction", size=18)

            #fig.tight_layout()
            #with np.testing.suppress_warnings() as sup:
                #sup.filter(UserWarning)
      #im = Image.fromarray(im)
      matplotlib.image.imsave(str(i) +".png", im)
      #im.save(str(i) + ".png")

                #fig.savefig(os.path.join(subdir, str(i) + ".png"))
            #plt.close(fig.number)
save_image_for_PU(data)