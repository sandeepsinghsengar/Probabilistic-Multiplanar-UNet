#!/bin/bash
# normal cpu stuff: allocate cpus, memory
#SBATCH --ntasks=1 --cpus-per-task=6 --mem=40GB
# we run on the gpu partition and we allocate 1 titanx gpu
#SBATCH -p gpu --gres=gpu:4
#We expect that our program should not run langer than 2 hours
#Note that a program will be killed once it exceeds this time!

#your script, in this case: write the hostname and the ids of the chosen gpus.
hostname
gpu_name=$CUDA_VISIBLE_DEVICES
echo $CUDA_VISIBLE_DEVICES
mp train -cf /home/bdp954/PMPU_tf_version2/MPU/MultiPlanarUNet/mpunet/train/prob_unet_config.py --overwrite
#mp train --overwrite


