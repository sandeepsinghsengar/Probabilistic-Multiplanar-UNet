

class NoLabelFileError(AttributeError): pass
class ReadOnlyAttributeError(AttributeError): pass
