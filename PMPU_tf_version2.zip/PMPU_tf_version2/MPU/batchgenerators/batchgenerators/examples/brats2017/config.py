brats_preprocessed_folder = "/media/fabian/DeepLearningData/BraTS2017_preprocessed"
brats_folder_with_downloaded_train_data = "/media/fabian/DeepLearningData/Brats17TrainingData"
num_threads_for_brats_example = 8